var classSPL_1_1BitStream =
[
    [ "IoState", "classSPL_1_1BitStream.html#a625155c1cff0423176f6d60eaf5f863f", null ],
    [ "Offset", "classSPL_1_1BitStream.html#ac8c963ad7384441fd080979a5b493ef6", null ],
    [ "Size", "classSPL_1_1BitStream.html#a0fa6e666e537662af6535bdfe531c484", null ],
    [ "clearIoStateBits", "group__BitStream.html#ga5e70a280f99df340459d17fe233db653", null ],
    [ "getIoState", "group__BitStream.html#ga2cb63b964936318a1fb9baee6b863a94", null ],
    [ "isEof", "group__BitStream.html#gacaa78bc6ca5990176d1fec79633a2250", null ],
    [ "isLimit", "group__BitStream.html#gad1b1900f96b386d535482e1b83be3a79", null ],
    [ "isOkay", "group__BitStream.html#gaeb66f3fffe171ceb9d9db0de36bf1cff", null ],
    [ "setIoState", "group__BitStream.html#gafd74a9efef141f80d3db703d3e2745be", null ],
    [ "setIoStateBits", "group__BitStream.html#gab03ff2969ad879d7daf7020f5594b3b6", null ]
];