var cgalUtil_8hpp =
[
    [ "angleBetweenVectors", "cgalUtil_8hpp.html#ga926726cf1d9a5949774cf184c11e9475", null ],
    [ "norm", "cgalUtil_8hpp.html#ga07bcbe101812e4dbe50476d7e89abf62", null ],
    [ "normalize", "cgalUtil_8hpp.html#ga23d8f1c6bba443c103070a2b3bd56511", null ],
    [ "operator*", "cgalUtil_8hpp.html#ga32f48b24be03a37dd2bf8cd25a52046f", null ],
    [ "operator/", "cgalUtil_8hpp.html#gaad03b015bc0c414fad680595c6825e6e", null ],
    [ "quaternionToRotation", "cgalUtil_8hpp.html#ga674cbb085071599c99b8bdef1ca943ec", null ],
    [ "rotationToQuaternion", "cgalUtil_8hpp.html#ga9cbf34a1ae47efc27552e8dd099bc61b", null ]
];