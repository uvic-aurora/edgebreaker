var structSPL_1_1PnmHeader =
[
    [ "height", "structSPL_1_1PnmHeader.html#a1978b7637de8de12a0f5cae1e690aea0", null ],
    [ "magic", "structSPL_1_1PnmHeader.html#ae89569e8629f15e555f60ac27a84eca6", null ],
    [ "maxVal", "structSPL_1_1PnmHeader.html#a0bfa65d9d9172b6e87e2c2e686457d86", null ],
    [ "sgnd", "structSPL_1_1PnmHeader.html#a17685f259608fca1c97e2e7ec2e1866a", null ],
    [ "width", "structSPL_1_1PnmHeader.html#a976de454b8a95de941b95d2e07d4dbc2", null ]
];