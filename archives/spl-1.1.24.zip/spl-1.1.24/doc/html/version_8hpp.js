var version_8hpp =
[
    [ "SPL_VERSION", "version_8hpp.html#ae4d0ea495c11721ea4f1c3d68b1912f9", null ]
];