var group__Filter__design =
[
    [ "bandpassFilter", "group__Filter__design.html#ga6402cb495afbdabd057d0553f833a95a", null ],
    [ "highpassFilter", "group__Filter__design.html#ga22cf54591e73dfc72b3386ebdb3f9ed7", null ],
    [ "lowpassFilter", "group__Filter__design.html#gaab880db5d7d30b971c5faa705758ca76", null ]
];