var structSPL_1_1Rotation__3 =
[
    [ "Real", "structSPL_1_1Rotation__3.html#a6875564f370ff96f501344092d724f0c", null ],
    [ "Vector_3", "structSPL_1_1Rotation__3.html#a03a16f1e607f5e5fb45ec09c0655a821", null ],
    [ "Rotation_3", "structSPL_1_1Rotation__3.html#a9e65426a9761b3ac5f8291c1562f2510", null ],
    [ "angle", "structSPL_1_1Rotation__3.html#aad161d94ed72a023f00e624e9ce65a31", null ],
    [ "axis", "structSPL_1_1Rotation__3.html#a5e43c113e40524341de062a158a76068", null ]
];