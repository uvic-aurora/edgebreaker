var NAVTREE =
[
  [ "Signal/Geometry Processing Library (SPL)", "index.html", [
    [ "Signal/Geometry Processing Library (SPL) Reference Manual (Version 1.1.24)", "index.html", [
      [ "Introduction", "index.html#intro", null ],
      [ "License", "index.html#license", null ],
      [ "Reporting Bugs", "index.html#bugs", null ]
    ] ],
    [ "Getting Started", "getting_started.html", "getting_started" ],
    [ "Frequently Asked Questions (FAQ)", "faq.html", null ],
    [ "Known Bugs", "known_bugs.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Classes", null, [
      [ "Class List", "annotated.html", "annotated" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classSPL_1_1Sequence1.html",
"group__Array2.html#ga627f171dad0df33b0f138a120d90231f",
"group__Sequence1.html#gab720f6ff9ddf78be2a49a1e3feb533da"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';