var group__Math__util =
[
    [ "absVal", "group__Math__util.html#gac61d3faf45ca48ec2acc1d6b637a9324", null ],
    [ "ceilDiv", "group__Math__util.html#gac0797f2cd74c9c84b032dfa35ddb8026", null ],
    [ "clip", "group__Math__util.html#ga10fe03a566e630e9427004018b4071bd", null ],
    [ "degToRad", "group__Math__util.html#gad36b8cdeba0d7979e3dec0d3df02cfc7", null ],
    [ "floorDiv", "group__Math__util.html#gac2a4d93c3129769bac3fad0cb4e2b745", null ],
    [ "mod", "group__Math__util.html#gac437cced669a62918bdf9878f2aebaa1", null ],
    [ "radToDeg", "group__Math__util.html#ga840c71714814d55ac3f72a3b66f7d51f", null ],
    [ "roundTowardZeroDiv", "group__Math__util.html#ga82eb348e0bb13f3f70ff4e42c6384981", null ],
    [ "signum", "group__Math__util.html#gaf3c98127d138aa9a55dfb583bef9bcf8", null ],
    [ "sinc", "group__Math__util.html#ga4fc2362acb83c8ba12888ab4b4ec490b", null ],
    [ "sqr", "group__Math__util.html#gad504346219317cffc75ee0b6f2b2bc46", null ]
];