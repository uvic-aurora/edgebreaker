var searchData=
[
  ['limitbit',['limitBit',['../classSPL_1_1BitStream.html#a139235a1097f1e35280759ff72e21e8e',1,'SPL::BitStream']]]
];
