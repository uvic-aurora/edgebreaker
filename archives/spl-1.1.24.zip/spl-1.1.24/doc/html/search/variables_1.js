var searchData=
[
  ['badbit',['badBit',['../classSPL_1_1BitStream.html#aba48cf6225a09992f3ed2bb7f25aed43',1,'SPL::BitStream']]]
];
