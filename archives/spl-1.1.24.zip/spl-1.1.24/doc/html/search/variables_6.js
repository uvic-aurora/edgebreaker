var searchData=
[
  ['magic',['magic',['../structSPL_1_1PnmHeader.html#ae89569e8629f15e555f60ac27a84eca6',1,'SPL::PnmHeader']]],
  ['maxval',['maxVal',['../structSPL_1_1PnmHeader.html#a0bfa65d9d9172b6e87e2c2e686457d86',1,'SPL::PnmHeader']]]
];
