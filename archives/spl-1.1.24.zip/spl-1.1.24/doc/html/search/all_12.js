var searchData=
[
  ['two_2ddimensional_20arrays',['Two-Dimensional Arrays',['../group__Array2.html',1,'']]],
  ['two_2ddimensional_20sequences',['Two-Dimensional Sequences',['../group__Sequence2.html',1,'']]],
  ['terminate',['terminate',['../classSPL_1_1MultiArithEncoder.html#a4df66b1c2285456b45f42ef7bb1118ca',1,'SPL::MultiArithEncoder::terminate()'],['../classSPL_1_1MultiArithDecoder.html#a39d6cfa1bcbdc8aa803fd3eb82714312',1,'SPL::MultiArithDecoder::terminate()'],['../classSPL_1_1BinArithEncoder.html#a660483f1e819849f8d7ab262768f9a74',1,'SPL::BinArithEncoder::terminate()'],['../classSPL_1_1BinArithDecoder.html#a5923fd241b5c85410913e04f636cc31e',1,'SPL::BinArithDecoder::terminate()'],['../classSPL_1_1MEncoder.html#a42c8bad8771c16893ddce20b64fb34fa',1,'SPL::MEncoder::terminate()'],['../classSPL_1_1MDecoder.html#aa937eb02e913e02f04afffbcee609c03',1,'SPL::MDecoder::terminate()']]],
  ['timer',['Timer',['../classSPL_1_1Timer.html',1,'SPL']]],
  ['timer_2ecpp',['Timer.cpp',['../Timer_8cpp.html',1,'']]],
  ['timer_2ehpp',['Timer.hpp',['../Timer_8hpp.html',1,'']]],
  ['translate',['translate',['../group__Sequence1.html#ga2ddb39ff6c0e8f1f53b47ba4f9f200e5',1,'SPL::Sequence1::translate()'],['../group__Sequence2.html#ga09b519eadc6f32a856b0eabb9becee13',1,'SPL::Sequence2::translate()'],['../group__Sequence1.html#ga2d5b936462997eed9f860e812ee8431b',1,'SPL::translate(const Sequence1&lt; T &gt; &amp;f, int delta)'],['../group__Sequence2.html#gad3505202e18541b62d6701e1052b7b6b',1,'SPL::translate(const Sequence2&lt; T &gt; &amp;f, int deltaX, int deltaY)']]],
  ['transpose',['transpose',['../group__Array2.html#gafdaa32bb45e93ecd3d17b0e63fd75bb4',1,'SPL']]]
];
