var searchData=
[
  ['polyphasejoin',['polyphaseJoin',['../group__Sequence1.html#gacdb17b76e562cd9551f62bdfc873a8b6',1,'SPL::polyphaseJoin(const Array1&lt; Sequence1&lt; T &gt; &gt; &amp;comps, int type)'],['../group__Sequence2.html#ga219d553e95d8139285b26e9c4e3bde2b',1,'SPL::polyphaseJoin(const Array2&lt; Sequence2&lt; T &gt; &gt; &amp;comps, int typeX, int typeY)']]],
  ['polyphasesplit',['polyphaseSplit',['../group__Sequence1.html#ga34f426df7de61a393a4dd1e000014402',1,'SPL::polyphaseSplit(const Sequence1&lt; T &gt; &amp;seq, int type, int numPhases)'],['../group__Sequence2.html#ga2cd5e0170b647a84e54d535b53a37eb5',1,'SPL::polyphaseSplit(const Sequence2&lt; T &gt; &amp;seq, int typeX, int numPhasesX, int typeY, int numPhasesY)']]],
  ['putbits',['putBits',['../classSPL_1_1OutputBitStream.html#ae481ebcd5c31b218872d8db9ab9490bc',1,'SPL::OutputBitStream']]]
];
