var searchData=
[
  ['full',['full',['../structSPL_1_1ConvolveMode.html#a6dc587d4f0f48bdbdf0dabc2521df361',1,'SPL::ConvolveMode']]]
];
