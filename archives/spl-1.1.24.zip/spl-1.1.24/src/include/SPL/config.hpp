/* src/include/SPL/config.hpp.  Generated from config.hpp.in by configure.  */
#ifndef SPL_CONFIG_HPP
#define SPL_CONFIG_HPP

/* Define this symbol if the libsnd library is available. */
#define SPL_HAVE_LIBSNDFILE 1

/* Define this symbol if the CGAL library is available. */
#define SPL_HAVE_CGAL 1

/* Define this symbol if the system header file sys/time.h exists. */
#define SPL_HAVE_SYS_TIME_H 1

/* Define this symbol if the system has the getrusage function. */
#define SPL_HAVE_GETRUSAGE 1

/* Define this symbol if the system has the gettimeofday function. */
#define SPL_HAVE_GETTIMEOFDAY 1

/* Define this symbol if the system has a Linux proc filesystem. */
#define SPL_HAVE_PROCFS 1

/* Define this symbol if the C++ TR1 bessel functions are available. */
#define SPL_HAVE_TR1_BESSEL 1

#endif
