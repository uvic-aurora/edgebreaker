var group__Image__IO =
[
    [ "decodePbm", "group__Image__IO.html#gaaddcb788ab53255340d671e063716d7b", null ],
    [ "decodePgm", "group__Image__IO.html#ga0311268cb7bd9bc5cb0c17433572dee5", null ],
    [ "decodePnm", "group__Image__IO.html#ga44a2f08f53305d4aaf39e6d040d182ff", null ],
    [ "decodePpm", "group__Image__IO.html#gafdefeacb6896106495c0efac2fdd6ef1", null ],
    [ "encodePbm", "group__Image__IO.html#ga9bb36f5ebfaa8161a71567e87bf63dca", null ],
    [ "encodePgm", "group__Image__IO.html#gacd58b7a5b1648f19977140a972685074", null ],
    [ "encodePnm", "group__Image__IO.html#ga3bf08918a0a39158e0463c11d6dfd979", null ],
    [ "encodePpm", "group__Image__IO.html#gac89f5640f3916029947b4051d4a618e6", null ]
];