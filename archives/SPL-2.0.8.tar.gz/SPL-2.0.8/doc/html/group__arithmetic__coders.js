var group__arithmetic__coders =
[
    [ "M-Coder", "group__MCoder.html", "group__MCoder" ],
    [ "Binary and m-ary Arithmetic Coders", "group__ArithCoder.html", "group__ArithCoder" ]
];