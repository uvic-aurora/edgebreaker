var structSPL_1_1Quaternion =
[
    [ "Real", "structSPL_1_1Quaternion.html#a34949a624c16b5864a27b92f50cad4eb", null ],
    [ "Vector_3", "structSPL_1_1Quaternion.html#a068da8036d38150bb1d1171bc72a00be", null ],
    [ "Quaternion", "structSPL_1_1Quaternion.html#a6a51d94ab845d89688deca9be499f18d", null ],
    [ "Quaternion", "structSPL_1_1Quaternion.html#a4764762e8de3b4f640b2670add466f26", null ],
    [ "scalar", "structSPL_1_1Quaternion.html#a664cab3e226e1c15ef8c548da8c352ff", null ],
    [ "vector", "structSPL_1_1Quaternion.html#a4ea6aec6bcd2ae7f97457b3b99353106", null ]
];