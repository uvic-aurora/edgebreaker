var Timer_8hpp =
[
    [ "getCurrentMemUsage", "Timer_8hpp.html#ga96d5c1802260f6b286b58b0e403560cf", null ],
    [ "getPeakMemUsage", "Timer_8hpp.html#ga50e2fce4e981a87db7c5fc5771966a2d", null ]
];