var modules =
[
    [ "Arrays and Sequences", "group__arrays__sequences.html", "group__arrays__sequences" ],
    [ "Bit Stream I/O", "group__BitStream.html", "group__BitStream" ],
    [ "Audio and Image Codecs", "group__audio__image__codecs.html", "group__audio__image__codecs" ],
    [ "Filter Design", "group__Filter__design.html", "group__Filter__design" ],
    [ "CPU and Memory Utilization", "group__Profiling.html", "group__Profiling" ],
    [ "Math Utilities", "group__Math__util.html", "group__Math__util" ],
    [ "CGAL Utilities", "group__CGAL__util.html", "group__CGAL__util" ],
    [ "Arithmetic Coders", "group__arithmetic__coders.html", "group__arithmetic__coders" ]
];