var files_dup =
[
    [ "Arcball.hpp", "Arcball_8hpp.html", "Arcball_8hpp" ],
    [ "demo/arithCoder.hpp", "demo_2arithCoder_8hpp_source.html", null ],
    [ "include/SPL/arithCoder.hpp", "include_2SPL_2arithCoder_8hpp_source.html", null ],
    [ "Array1.hpp", "Array1_8hpp.html", "Array1_8hpp" ],
    [ "Array2.hpp", "Array2_8hpp.html", "Array2_8hpp" ],
    [ "audioFile.hpp", "audioFile_8hpp.html", "audioFile_8hpp" ],
    [ "bitStream.hpp", "bitStream_8hpp.html", null ],
    [ "cgalUtil.hpp", "cgalUtil_8hpp.html", "cgalUtil_8hpp" ],
    [ "filterDesign.hpp", "filterDesign_8hpp.html", "filterDesign_8hpp" ],
    [ "math.hpp", "math_8hpp.html", "math_8hpp" ],
    [ "mCoder.hpp", "mCoder_8hpp.html", null ],
    [ "misc.hpp", "misc_8hpp.html", "misc_8hpp" ],
    [ "pnmCodec.cpp", "pnmCodec_8cpp.html", "pnmCodec_8cpp" ],
    [ "pnmCodec.hpp", "pnmCodec_8hpp.html", "pnmCodec_8hpp" ],
    [ "Sequence.hpp", "Sequence_8hpp.html", [
      [ "ConvolveMode", "structSPL_1_1ConvolveMode.html", null ]
    ] ],
    [ "Sequence1.hpp", "Sequence1_8hpp.html", "Sequence1_8hpp" ],
    [ "Sequence2.cpp", "Sequence2_8cpp.html", "Sequence2_8cpp" ],
    [ "Sequence2.hpp", "Sequence2_8hpp.html", "Sequence2_8hpp" ],
    [ "Timer.cpp", "Timer_8cpp.html", "Timer_8cpp" ],
    [ "Timer.hpp", "Timer_8hpp.html", "Timer_8hpp" ]
];