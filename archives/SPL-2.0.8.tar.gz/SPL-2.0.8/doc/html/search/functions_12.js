var searchData=
[
  ['unshare',['unshare',['../group__Array2.html#ga5c592d99b83437003872442bb0de52f1',1,'SPL::Array2']]],
  ['upsample',['upsample',['../group__Sequence1.html#ga162d7f981e031faf4ef630974010727d',1,'SPL::upsample(const Sequence1&lt; T &gt; &amp;f, int factor, int pad=0)'],['../group__Sequence2.html#ga58d1736fede504d583cf5345742fbc6e',1,'SPL::upsample(const Sequence2&lt; T &gt; &amp;f, int factorX, int factorY)'],['../group__Sequence2.html#gad3cf936671495a822cd2bf88af5a7100',1,'SPL::upsample(const Sequence2&lt; T &gt; &amp;f, int factorX, int factorY, int padX, int padY)']]]
];
