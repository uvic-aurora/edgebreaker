var searchData=
[
  ['eofbit',['eofBit',['../classSPL_1_1BitStream.html#ae1c743e6a4de08c0008052112e4398de',1,'SPL::BitStream']]]
];
