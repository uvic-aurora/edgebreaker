var searchData=
[
  ['convolvemode',['ConvolveMode',['../structSPL_1_1ConvolveMode.html',1,'SPL']]]
];
