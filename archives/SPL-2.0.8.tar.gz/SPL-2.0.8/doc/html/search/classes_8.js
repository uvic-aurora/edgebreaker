var searchData=
[
  ['rotation_5f3',['Rotation_3',['../structSPL_1_1Rotation__3.html',1,'SPL']]],
  ['rotation_5f3_3c_20kernel_20_3e',['Rotation_3&lt; Kernel &gt;',['../structSPL_1_1Rotation__3.html',1,'SPL']]]
];
