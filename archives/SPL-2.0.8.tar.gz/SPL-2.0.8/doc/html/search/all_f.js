var searchData=
[
  ['quaternion',['Quaternion',['../structSPL_1_1Quaternion.html',1,'SPL::Quaternion&lt; T &gt;'],['../structSPL_1_1Quaternion.html#a6a51d94ab845d89688deca9be499f18d',1,'SPL::Quaternion::Quaternion()'],['../structSPL_1_1Quaternion.html#a4764762e8de3b4f640b2670add466f26',1,'SPL::Quaternion::Quaternion(Real scalar_, const Vector_3 &amp;vector_)']]],
  ['quaterniontorotation',['quaternionToRotation',['../group__CGAL__util.html#ga674cbb085071599c99b8bdef1ca943ec',1,'SPL']]]
];
