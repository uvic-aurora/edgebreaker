var searchData=
[
  ['samedomainconstext',['sameDomainConstExt',['../structSPL_1_1ConvolveMode.html#a3a15bb188094515a3b94c2047b90cc5d',1,'SPL::ConvolveMode']]],
  ['samedomainperext',['sameDomainPerExt',['../structSPL_1_1ConvolveMode.html#a88ec25569cddd6646c2121c844614c28',1,'SPL::ConvolveMode']]],
  ['samedomainsymext0',['sameDomainSymExt0',['../structSPL_1_1ConvolveMode.html#ac29d6498c9a94eefaf850d730baa36e2',1,'SPL::ConvolveMode']]],
  ['samedomainzeroext',['sameDomainZeroExt',['../structSPL_1_1ConvolveMode.html#acf7dd75c22db9f9db8921dff28d39a95',1,'SPL::ConvolveMode']]],
  ['scalar',['scalar',['../structSPL_1_1Quaternion.html#a664cab3e226e1c15ef8c548da8c352ff',1,'SPL::Quaternion']]],
  ['sgnd',['sgnd',['../structSPL_1_1PnmHeader.html#a17685f259608fca1c97e2e7ec2e1866a',1,'SPL::PnmHeader']]]
];
