var searchData=
[
  ['size',['Size',['../classSPL_1_1BitStream.html#a0fa6e666e537662af6535bdfe531c484',1,'SPL::BitStream']]]
];
