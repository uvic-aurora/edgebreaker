var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxy~",
  1: "abcimopqrst",
  2: "abcfmpst",
  3: "abcdefghilmnopqrstu~",
  4: "abefhlmpsvw",
  5: "ceikoprsvxy",
  6: "p",
  7: "s",
  8: "abcfimot",
  9: "fgikos"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

