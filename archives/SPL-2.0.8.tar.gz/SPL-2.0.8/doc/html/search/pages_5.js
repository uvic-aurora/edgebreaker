var searchData=
[
  ['signal_2fgeometry_20processing_20library_20_28spl_29_20reference_20manual_20_28version_202_2e0_2e8_29',['Signal/Geometry Processing Library (SPL) Reference Manual (Version 2.0.8)',['../index.html',1,'']]]
];
