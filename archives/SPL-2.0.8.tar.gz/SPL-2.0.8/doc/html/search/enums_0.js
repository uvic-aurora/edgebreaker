var searchData=
[
  ['pnmfmt',['PnmFmt',['../pnmCodec_8hpp.html#ac943be7540c680cc8e232f2691e77897',1,'SPL']]],
  ['pnmmagic',['PnmMagic',['../pnmCodec_8hpp.html#ab1d943a43a3602fc4624ff0dc977e41b',1,'SPL']]],
  ['pnmtype',['PnmType',['../pnmCodec_8hpp.html#a9f63cb4591da67dd5634aad0fb96ec01',1,'SPL']]]
];
