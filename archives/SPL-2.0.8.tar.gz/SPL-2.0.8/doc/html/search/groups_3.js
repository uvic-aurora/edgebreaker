var searchData=
[
  ['filter_20design',['Filter Design',['../group__Filter__design.html',1,'']]]
];
