var searchData=
[
  ['organization_20of_20the_20manual',['Organization of the Manual',['../organization.html',1,'getting_started']]]
];
