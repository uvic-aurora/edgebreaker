var classSPL_1_1BitStream =
[
    [ "IoState", "classSPL_1_1BitStream.html#a625155c1cff0423176f6d60eaf5f863f", null ],
    [ "Offset", "classSPL_1_1BitStream.html#ac8c963ad7384441fd080979a5b493ef6", null ],
    [ "Size", "classSPL_1_1BitStream.html#a0fa6e666e537662af6535bdfe531c484", null ],
    [ "clearIoStateBits", "group__BitStream.html#ga5e70a280f99df340459d17fe233db653", null ],
    [ "getIoState", "group__BitStream.html#gab8d9db934a97fc2f4816b6530151b383", null ],
    [ "isEof", "group__BitStream.html#gaf925a4070bc78ee90542dbd7a3edc0f6", null ],
    [ "isLimit", "group__BitStream.html#ga0fc0c72fa8036608f8f7afb56b0b31b4", null ],
    [ "isOkay", "group__BitStream.html#ga8395a2c8cfe7ba3d78e17836020485f3", null ],
    [ "setIoState", "group__BitStream.html#gafd74a9efef141f80d3db703d3e2745be", null ],
    [ "setIoStateBits", "group__BitStream.html#gab03ff2969ad879d7daf7020f5594b3b6", null ]
];