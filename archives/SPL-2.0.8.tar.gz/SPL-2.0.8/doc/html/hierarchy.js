var hierarchy =
[
    [ "SPL::Arcball< T >", "classSPL_1_1Arcball.html", null ],
    [ "SPL::Arcball< Kernel >", "classSPL_1_1Arcball.html", null ],
    [ "SPL::Array1< T >", "classSPL_1_1Array1.html", null ],
    [ "SPL::Array2< T >", "classSPL_1_1Array2.html", null ],
    [ "SPL::BinArithCoderContextStat", "structSPL_1_1BinArithCoderContextStat.html", null ],
    [ "SPL::BinArithDecoder", "classSPL_1_1BinArithDecoder.html", null ],
    [ "SPL::BinArithEncoder", "classSPL_1_1BinArithEncoder.html", null ],
    [ "SPL::BitStream", "classSPL_1_1BitStream.html", [
      [ "SPL::InputBitStream", "classSPL_1_1InputBitStream.html", null ],
      [ "SPL::OutputBitStream", "classSPL_1_1OutputBitStream.html", null ]
    ] ],
    [ "SPL::ConvolveMode", "structSPL_1_1ConvolveMode.html", null ],
    [ "SPL::MDecoder", "classSPL_1_1MDecoder.html", null ],
    [ "SPL::MEncoder", "classSPL_1_1MEncoder.html", null ],
    [ "SPL::MultiArithDecoder", "classSPL_1_1MultiArithDecoder.html", null ],
    [ "SPL::MultiArithEncoder", "classSPL_1_1MultiArithEncoder.html", null ],
    [ "SPL::PnmHeader", "structSPL_1_1PnmHeader.html", null ],
    [ "SPL::Quaternion< T >", "structSPL_1_1Quaternion.html", null ],
    [ "SPL::Rotation_3< T >", "structSPL_1_1Rotation__3.html", null ],
    [ "SPL::Rotation_3< Kernel >", "structSPL_1_1Rotation__3.html", null ],
    [ "SPL::Sequence1< T >", "classSPL_1_1Sequence1.html", null ],
    [ "SPL::Sequence2< T >", "classSPL_1_1Sequence2.html", null ],
    [ "SPL::Timer", "classSPL_1_1Timer.html", null ]
];