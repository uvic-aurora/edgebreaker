var group__Profiling =
[
    [ "Timer", "classSPL_1_1Timer.html", [
      [ "get", "classSPL_1_1Timer.html#a6bd558c9bbc4c5b7c0d57339a878d31b", null ],
      [ "start", "classSPL_1_1Timer.html#a30853fb65b225d817e77aa310e572379", null ],
      [ "stop", "classSPL_1_1Timer.html#a4097c903109e41d12ec946e176383c19", null ]
    ] ],
    [ "getCurrentMemUsage", "group__Profiling.html#ga96d5c1802260f6b286b58b0e403560cf", null ],
    [ "getPeakMemUsage", "group__Profiling.html#ga50e2fce4e981a87db7c5fc5771966a2d", null ]
];