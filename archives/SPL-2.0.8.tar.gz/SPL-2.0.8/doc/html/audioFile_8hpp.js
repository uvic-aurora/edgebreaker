var audioFile_8hpp =
[
    [ "loadAudioFile", "audioFile_8hpp.html#ga45ca575312caad67d568ff5ca4e60397", null ],
    [ "saveAudioFile", "audioFile_8hpp.html#ga1f4f9c6bf7442399a383ca94a3a66d5a", null ]
];